﻿/*****************************************************
 * This is the provider class built on Resources which allows 
 * the provider to add and remove resources.
 ****************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Exercise2.Program;

namespace Exercise2
{
    class Provider : Resources
    {
        public Provider(ResourceTypes resourceType, int unitsValue) : base(resourceType, unitsValue)
        {
            this.RType = resourceType;
            this.Units = unitsValue;
        }

        /************************************************
        * This function adds the resources based on given
        * resource type and unit value
        ************************************************/
        public Dictionary<ResourceTypes, int> AdditionOfResources(Dictionary<ResourceTypes, int> resourcesTable)
        {
            foreach (int item in Enum.GetValues(typeof(ResourceTypes)))
            {
                string enumTypes = Enum.GetName(typeof(ResourceTypes), item).ToString();
                if (enumTypes.Equals(RType.ToString()))
                {
                    Resources resource = new Resources(RType, Units + item);
                    try
                    {
                        resourcesTable.Add(resource.RType, resource.Units);
                    }
                    catch (ArgumentException)
                    {
                        Console.WriteLine("This key has been already been added.");
                    }
                }
            }
            return resourcesTable;
        }

        /**************************************************
        * This function removes resources based on given
        * resource type and unit value 
        ****************************************************/
        public Dictionary<ResourceTypes, int> RemoveOfResources(Dictionary<ResourceTypes, int> resourcesTable)
        {
            foreach (int item in Enum.GetValues(typeof(ResourceTypes)))
            {
                string enumTypes = Enum.GetName(typeof(ResourceTypes), item).ToString();
                if (enumTypes.Equals(RType.ToString()))
                {
                    int dicValue = resourcesTable[RType];
                    if (dicValue < Units)
                    {
                        Console.WriteLine("You are remove more units than available");
                        break;
                    }
                    Resources resource = new Resources(RType, (dicValue - Units));
                    resourcesTable[resource.RType] = resource.Units;
                }
            }
            return resourcesTable;
        }
    }
}
