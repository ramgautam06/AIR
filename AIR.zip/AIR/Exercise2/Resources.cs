﻿/***********************************************
 * This class has only two resource data that 
 * defines resource type based on resource value
 **********************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Exercise2.Program;

namespace Exercise2
{
    class Resources
    {
        public ResourceTypes RType = new ResourceTypes();
        public int Units = 0;

        public Resources(ResourceTypes rty, int unitsValue)
        {
            this.RType = rty;
            this.Units = unitsValue;
        }
    }
}
