﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Exercise2.Program;

namespace Exercise2
{
    class Requirements
    {
        public ResourceTypes ReqType = new ResourceTypes();
        public int requiredUnits = 0;

        public Requirements(ResourceTypes resourceType, int reqUnits)
        {
            this.ReqType = resourceType;
            this.requiredUnits = reqUnits;
        }
    }
}
