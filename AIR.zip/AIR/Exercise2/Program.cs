﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise2
{
    class Program
    {
        public enum ResourceTypes { Hardware = 5, Firmware = 2, Software = 4, Other = 1 }

        static void Main(string[] args)
        {
            Dictionary<ResourceTypes, int> resourcesDic = new Dictionary<ResourceTypes, int>();
            Dictionary<ResourceTypes, int> requirementDic = new Dictionary<ResourceTypes, int>();

            List<ResourceTypes> listResourceType = new List<ResourceTypes>() { ResourceTypes.Hardware, ResourceTypes.Firmware, ResourceTypes.Software, ResourceTypes.Other };

            int a = 0;
            int addResources = 20;
            int removeResources = 2;

            int addReq = 3;
            int removeReq = 1;
            foreach (int name in Enum.GetValues(typeof(ResourceTypes)))
            {
                //allocating and adding resources 
                Provider provAdd = new Provider(listResourceType[a], addResources);
                resourcesDic = provAdd.AdditionOfResources(resourcesDic);

                Provider provRemove = new Provider(listResourceType[a], removeResources);
                resourcesDic = provRemove.RemoveOfResources(resourcesDic);

                //allocating and removing Requirements
                Demands demandAdd = new Demands(listResourceType[a], addReq);
                requirementDic = demandAdd.AdditionOfRequirements(requirementDic);

                Demands demandRemove = new Demands(listResourceType[a], removeReq);
                requirementDic = demandRemove.RemovalOfRequirements(requirementDic);

                a++;

                addResources += 10;
                removeResources += 2;

                addReq += 3;
                removeReq += 1;
            }

            Console.WriteLine("----------- Available Resources After Adding and Removing----------");
            for (int index = 0; index < resourcesDic.Count; index++)
            {
                var item = resourcesDic.ElementAt(index);
                Console.WriteLine(string.Format("{0} = {1}", item.Key, item.Value));
            }
            Console.WriteLine("\n");

            Console.WriteLine("----------- Available Requirements After Adding and Removing --------");
            for (int index = 0; index < requirementDic.Count; index++)
            {
                var item = requirementDic.ElementAt(index);
                Console.WriteLine(string.Format("{0} = {1}", item.Key, item.Value));
            }
            Console.WriteLine("\n");

            Dictionary<ResourceTypes, int> multipleTimes = Multiples(resourcesDic, requirementDic);
            Console.WriteLine("----------Provider has following Quantity Available----------");
            for (int i = 0; i < multipleTimes.Count; i++)
            {
                var item = multipleTimes.ElementAt(i);
                Console.Write(string.Format("{0} = {1}", item.Key, item.Value) + "  ");
            }
            Console.WriteLine("\n");

            Console.ReadLine();
        }

        /**********************************************
         * This funtion returns the dictionary of
         * available resources
         **********************************************/
        public static Dictionary<ResourceTypes, int> Multiples(Dictionary<ResourceTypes, int> resourcesDic, Dictionary<ResourceTypes, int> requirementDic)
        {
            Dictionary<ResourceTypes, int> wholeMultiples = new Dictionary<ResourceTypes, int>();
            for (int index = 0; index < resourcesDic.Count; index++)
            {
                var itemResources = resourcesDic.ElementAt(index);
                var itemRequirement = requirementDic.ElementAt(index);

                wholeMultiples.Add(itemResources.Key, (itemResources.Value / itemRequirement.Value));
            }
            return wholeMultiples;
        }
    }
}
