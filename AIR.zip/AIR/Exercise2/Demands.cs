﻿/*****************************************************
 * This is the Demand class built on Requirements which allows 
 * the user to add and remove requirements.
 ****************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Exercise2.Program;

namespace Exercise2
{
    class Demands : Requirements
    {
        public Demands(ResourceTypes resourceTypes, int unitsValue) : base(resourceTypes, unitsValue)
        {
            this.ReqType = resourceTypes;
            this.requiredUnits = unitsValue;
        }

        /************************************************
         * This function adds the requirements based on given
         * requirement type and unit value
         ************************************************/
        public Dictionary<ResourceTypes, int> AdditionOfRequirements(Dictionary<ResourceTypes, int> requirementDic)
        {
            foreach (int item in Enum.GetValues(typeof(ResourceTypes)))
            {
                string enumTypes = Enum.GetName(typeof(ResourceTypes), item).ToString();
                if (enumTypes.Equals(ReqType.ToString()))
                {
                    Requirements requirement = new Requirements(ReqType, requiredUnits + item);

                    try
                    {
                        requirementDic.Add(requirement.ReqType, requirement.requiredUnits);
                    }
                    catch (ArgumentException)
                    {
                        Console.WriteLine("This key has been already added.");
                    }
                }
            }
            return requirementDic;
        }

        /************************************************
        * This function removes the requirements based on given
        * requirement type and unit value
        ************************************************/
        public Dictionary<ResourceTypes, int> RemovalOfRequirements(Dictionary<ResourceTypes, int> requirementDic)
        {
            foreach (int item in Enum.GetValues(typeof(ResourceTypes)))
            {
                string enumTypes = Enum.GetName(typeof(ResourceTypes), item).ToString();
                if (enumTypes.Equals(ReqType.ToString()))
                {
                    int dicValue = requirementDic[ReqType];
                    if (dicValue < requiredUnits)
                    {
                        Console.WriteLine("You cannot remove more units than available");
                        break;
                    }

                    Requirements requirement = new Requirements(ReqType, (dicValue - requiredUnits));
                    requirementDic[requirement.ReqType] = requirement.requiredUnits;
                }
            }

            return requirementDic;
        }
    }
}
