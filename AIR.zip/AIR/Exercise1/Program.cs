﻿/****************************************************************
 * Author: Ram Gautam 
 * Initial Date: 08/30/2021
 * The program takes two valid integer arguments and prints all 
 * the evenly divisible numbers by the second number until the 
 * frist number is greater than 0.
 *****************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Checking the number of Command Line arguments.
            if (args.Length != 2) { Console.WriteLine("There must be two arguments to run the program."); return; }

            try
            {
                int firstNum = Convert.ToInt32(args[0]);
                int secondNum = Convert.ToInt32(args[1]);

                //catching the Exceptions cases not able to be handled by Eror Exception.
                if (firstNum < 2) { Console.WriteLine(string.Format("First number,{0}, cannot be less than 2.", args[0])); return; } //1
                else if (secondNum > firstNum) { Console.WriteLine(string.Format("{0}, is smaller than {1}.", args[0], args[1])); return; }//2
                else if (firstNum % secondNum != 0) { Console.WriteLine(string.Format("{0}, is not evenly divisible {1}.", args[0], args[1])); return; }//3
                else if (firstNum < 0 || secondNum < 0) { Console.WriteLine(string.Format("{0} and {1}, either number cannot be Negative.", args[0], args[1])); return; }//4
                else if (firstNum >= 1000) { Console.WriteLine(string.Format("First Number must be less than 1000.")); return; }//5

                //Checking all the numbers until it reaches 0.
                while (firstNum > 0)
                {
                    if (firstNum % secondNum == 0) { Console.Write(firstNum + " "); }
                    firstNum -= 1;
                }
            }
            catch (FormatException) //6
            {
                Console.WriteLine(string.Format("The inputs,{0} and {1},must be integer.", args[0], args[1]));
            }
            catch (DivideByZeroException)//7
            {
                Console.WriteLine(string.Format("Division of,{0}, by Zero.", args[0]));
            }
            Console.ReadLine();
        }
    }
}
